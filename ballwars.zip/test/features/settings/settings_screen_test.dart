import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ballwars/core/theme/app_theme.dart';
import 'package:ballwars/features/settings/data/app_settings_repository.dart';
import 'package:ballwars/features/settings/domain/app_settings.dart';
import 'package:ballwars/features/settings/presentation/app_settings_scope.dart';
import 'package:ballwars/features/settings/presentation/settings_screen.dart';

class _FakeRepo implements AppSettingsRepository {
  final List<AppSettings> saved = [];

  @override
  Future<AppSettings> load() async => AppSettings.defaults;

  @override
  Future<void> save(AppSettings settings) async => saved.add(settings);
}

class _Admin implements AdminAuth {
  @override
  Future<bool> isAdmin() async => true;

  @override
  String? get email => 'admin@example.com';

  @override
  Future<void> signIn(
    String email,
    String password, {
    bool rememberMe = false,
  }) async {}

  @override
  Future<void> signOut() async {}
}

class _SignedOutAdmin implements AdminAuth {
  bool signedIn = false;
  bool? remembered;

  @override
  String? get email => signedIn ? 'admin@example.com' : null;
  @override
  Future<bool> isAdmin() async => signedIn;
  @override
  Future<void> signIn(
    String email,
    String password, {
    bool rememberMe = false,
  }) async {
    signedIn = true;
    remembered = rememberMe;
  }

  @override
  Future<void> signOut() async => signedIn = false;
}

void main() {
  testWidgets(
    'admin Ball Studio saves shared appearance through the settings scope',
    (tester) async {
      final repository = _FakeRepo();
      final settings = ValueNotifier(AppSettings.defaults);
      await tester.pumpWidget(
        AppSettingsScope(
          settings: settings,
          repository: repository,
          adminAuth: _Admin(),
          child: MaterialApp(
            theme: AppTheme.build(AppPalettes.midnight),
            home: const SettingsScreen(),
          ),
        ),
      );
      await tester.pumpAndSettle();
      await tester.tap(find.text('Appearance'));
      await tester.pumpAndSettle();
      await tester.scrollUntilVisible(
        find.byKey(const ValueKey('open-ball-studio')),
        300,
        scrollable: find
            .descendant(
              of: find.byType(ListView).first,
              matching: find.byType(Scrollable),
            )
            .first,
        maxScrolls: 30,
      );
      await tester.tap(find.byKey(const ValueKey('open-ball-studio')));
      await tester.pumpAndSettle();
      expect(find.text('Ball Studio'), findsOneWidget);
      await tester.tap(find.widgetWithText(Tab, 'HP bar'));
      await tester.pumpAndSettle();
      await tester.tap(find.byType(DropdownButtonFormField<HpBarSize>));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Medium').last);
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('save-ball-studio')));
      await tester.pumpAndSettle();
      expect(settings.value.ballAppearance.hpBarSize, HpBarSize.medium);
      expect(repository.saved.last.ballAppearance.hpBarSize, HpBarSize.medium);
    },
  );
  testWidgets('admin sign-in offers Remember me and passes the choice', (
    tester,
  ) async {
    final auth = _SignedOutAdmin();
    await tester.pumpWidget(
      AppSettingsScope(
        settings: ValueNotifier(AppSettings.defaults),
        repository: _FakeRepo(),
        adminAuth: auth,
        child: MaterialApp(
          theme: AppTheme.build(AppPalettes.midnight),
          home: const SettingsScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.text('Admin sign-in'));
    await tester.pumpAndSettle();
    expect(find.text('Remember me'), findsOneWidget);
    await tester.enterText(
      find.widgetWithText(TextField, 'Email'),
      'admin@example.com',
    );
    await tester.enterText(
      find.widgetWithText(TextField, 'Password'),
      'secret',
    );
    await tester.tap(find.text('Remember me'));
    await tester.tap(find.widgetWithText(FilledButton, 'Sign in'));
    await tester.pumpAndSettle();
    expect(auth.remembered, isTrue);
  });

  testWidgets(
    'the admin picks the match music for everyone and can play each track',
    (tester) async {
      tester.view.physicalSize = const Size(1080, 4000);
      tester.view.devicePixelRatio = 2;
      addTearDown(tester.view.reset);
      final repo = _FakeRepo();
      final settings = ValueNotifier(AppSettings.defaults);
      await tester.pumpWidget(
        AppSettingsScope(
          settings: settings,
          repository: repo,
          adminAuth: _Admin(),
          child: MaterialApp(
            theme: AppTheme.build(AppPalettes.midnight),
            home: const SettingsScreen(),
          ),
        ),
      );
      await tester.pumpAndSettle();

      await tester.tap(find.text('Audio'));
      await tester.pumpAndSettle();

      expect(find.text('MUSIC'), findsOneWidget);
      expect(find.text('Match music'), findsOneWidget);
      expect(find.text('Home music'), findsOneWidget);
      for (final name in [
        'Arena',
        'Turbo',
        'Sunny Day',
        'Boss Fight',
        'Chill Out',
      ]) {
        expect(find.text(name), findsOneWidget);
        expect(find.byTooltip('Play $name'), findsOneWidget);
      }

      await tester.tap(find.text('Boss Fight'));
      await tester.pumpAndSettle();
      expect(repo.saved.single.musicId, 'boss');
      expect(settings.value.musicId, 'boss');

      // Home music lives in the second tab and is picked the same way.
      await tester.tap(find.text('Home music'));
      await tester.pumpAndSettle();
      for (final name in ['Drift', 'Lantern', 'Tide', 'Hearth', 'Starlight']) {
        expect(find.byTooltip('Play $name'), findsOneWidget);
      }
      await tester.tap(find.text('Tide'));
      await tester.pumpAndSettle();
      expect(repo.saved.last.menuMusicId, 'tide');
    },
  );

  testWidgets('the admin sets when slow motion starts', (tester) async {
    tester.view.physicalSize = const Size(1080, 5000);
    tester.view.devicePixelRatio = 2;
    addTearDown(tester.view.reset);
    final repo = _FakeRepo();
    final settings = ValueNotifier(AppSettings.defaults);
    await tester.pumpWidget(
      AppSettingsScope(
        settings: settings,
        repository: repo,
        adminAuth: _Admin(),
        child: MaterialApp(
          theme: AppTheme.build(AppPalettes.midnight),
          home: const SettingsScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.textContaining('down to 10 lines'), findsOneWidget);
    await tester.drag(
      find.byKey(const ValueKey('slow-motion-slider')),
      const Offset(-2000, 0),
    ); // all the way left: off
    await tester.pumpAndSettle();
    expect(find.text('Off: matches never slow down.'), findsOneWidget);
    await tester.tap(find.text('Save slow motion'));
    await tester.pumpAndSettle();
    expect(repo.saved.single.slowMotionLines, 0);
  });

  testWidgets('the admin sets the minimum shrinking-arena size', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(1080, 6000);
    tester.view.devicePixelRatio = 2;
    addTearDown(tester.view.reset);
    final repo = _FakeRepo();
    final settings = ValueNotifier(AppSettings.defaults);
    await tester.pumpWidget(
      AppSettingsScope(
        settings: settings,
        repository: repo,
        adminAuth: _Admin(),
        child: MaterialApp(
          theme: AppTheme.build(AppPalettes.midnight),
          home: const SettingsScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('Minimum shrinking-arena size: 60%'), findsOneWidget);
    await tester.drag(
      find.byKey(const ValueKey('minimum-arena-scale-slider')),
      const Offset(-2000, 0),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.text('Save arena size'));
    await tester.pumpAndSettle();
    expect(repo.saved.single.minimumArenaScale, 0.40);
  });

  testWidgets('the admin can turn the arena ball glow off', (tester) async {
    tester.view.physicalSize = const Size(1080, 6000);
    tester.view.devicePixelRatio = 2;
    addTearDown(tester.view.reset);
    final repo = _FakeRepo();
    final settings = ValueNotifier(AppSettings.defaults);
    await tester.pumpWidget(
      AppSettingsScope(
        settings: settings,
        repository: repo,
        adminAuth: _Admin(),
        child: MaterialApp(
          theme: AppTheme.build(AppPalettes.midnight),
          home: const SettingsScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    await tester.tap(find.text('Appearance'));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const ValueKey('choose-default-arena')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('arena-option-desert')));
    await tester.pumpAndSettle();
    expect(repo.saved.last.arenaDecoration, ArenaDecoration.desert);
    expect(settings.value.arenaDecoration, ArenaDecoration.desert);

    expect(settings.value.ballGlowEnabled, isTrue);
    await tester.tap(find.text('Outer glow in the arena'));
    await tester.pumpAndSettle();
    expect(repo.saved.last.ballGlowEnabled, isFalse);
    expect(settings.value.ballGlowEnabled, isFalse);

    // Default effect visuals moved to Skill Management > Global.
    expect(
      find.byKey(const ValueKey('effect-render-Default effect visuals')),
      findsNothing,
    );

    const purple = Color(0xFF8E44AD);
    await tester.tap(find.byKey(ValueKey('blood-${purple.toARGB32()}')));
    await tester.pumpAndSettle();
    expect(repo.saved.last.bloodColor, purple);
    expect(settings.value.bloodColor, purple);

    await tester.enterText(
      find.widgetWithText(TextField, 'Large line'),
      'BALL WARS',
    );
    await tester.enterText(
      find.widgetWithText(TextField, 'Small line'),
      'fight now',
    );
    await tester.tap(find.text('Save arena text'));
    await tester.pumpAndSettle();
    expect(repo.saved.last.arenaTitle, 'BALL WARS');
    expect(repo.saved.last.arenaSubtitle, 'fight now');
  });

  testWidgets('the admin can switch slow motion to before the win', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(1080, 5000);
    tester.view.devicePixelRatio = 2;
    addTearDown(tester.view.reset);
    final repo = _FakeRepo();
    await tester.pumpWidget(
      AppSettingsScope(
        settings: ValueNotifier(AppSettings.defaults),
        repository: repo,
        adminAuth: _Admin(),
        child: MaterialApp(
          theme: AppTheme.build(AppPalettes.midnight),
          home: const SettingsScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    await tester.tap(find.text('Before the win'));
    await tester.pumpAndSettle();
    expect(find.text('Starts 1.5 s before the winning cut.'), findsOneWidget);
    await tester.tap(find.text('Save slow motion'));
    await tester.pumpAndSettle();
    expect(repo.saved.single.slowMotionBeforeWinSeconds, 1.5);
  });
}
